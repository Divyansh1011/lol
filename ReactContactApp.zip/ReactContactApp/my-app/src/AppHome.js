import { Component } from "react";
import { AppContent } from "./AppContent";
import AppFooter from "./AppFooter";
import AppHeader from "./AppHeader";




export class AppHome extends Component {

    render() {

        const footerProps = {
            website: "https://abc.co",
            company: 'RNishad Inc',
            year: 2022
        };
        return (
            <div className="app-home">
                <AppHeader title="Addressbook App -v1.0" subheading="Created by Ramnath" />

                <AppContent />
                {/* <AppFooter website={footerProps.website} company={footerProps.company} year={footerProps.year}/> */}
                <AppFooter {...footerProps} />
            </div>
        )
    }
}
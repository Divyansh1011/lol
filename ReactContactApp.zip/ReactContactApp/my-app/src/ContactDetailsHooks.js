import { useParams } from "react-router-dom";   
import { useEffect,useState } from "react";

const ContactDetailsHooks =()=>{

    const {id}=useParams();
    
    let [contact,setContact]=useState({});
    useEffect(()=>{
        fetch("http://localhost:4300/contacts/"+id)
        .then(response => response.json())
        .then(data => setContact(data));
        console.log('useEffect');
    },[]);

    return(
        <div className="row">
                <div className="col-md-4">
                    <img src={"/"+contact.picture} 
                        style={{height:'200px'}}
                        className="img img-thumbnail" />
                </div>
                <div className="col-md-8">
                    <table className="table table-bordered">
                        <tr>
                            <td>Name</td>
                            <td>{contact.name}</td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>{contact.email}</td>
                        </tr>
                        <tr>
                            <td>Phone</td>
                            <td>{contact.phone}</td>
                        </tr>
                    </table>
                </div>
            </div>   

    )
}

export default ContactDetailsHooks;
import React,{Component} from 'react'

export default class AppCounter extends Component{
    state={
        count:0        
    }

    number=0;

    constructor(){
        super();
        //this.setState({count:1}); //not recommended
        console.log('constructor is called');
    }
    static getDerivedStateFromProps(){
        console.log('getDerivedStateFromProps() is called');
        return null;
    }

    render(){
        console.log('render() is called');
        return(<div>
            <h1>React Componet LifeCycle Methods</h1>
            <hr/>
            <h3>{this.props.title}</h3>
            <p>Counter value :{this.state.count}</p>
            <p>Number value :{this.number}</p>
           <button className='btn btn-primary'
            onClick={()=>{
                this.setState({count:this.state.count+1});                
            }}>
                increment
            </button>
            <button className='btn btn-warning'
            onClick={()=>{
                  this.number++;
                  console.log('number:',this.number); 
                  this.forceUpdate();            
            }}>
                increment num
            </button>
        </div>)
    }

    shouldComponentUpdate(){
        console.log('shouldComponentUpdate() is called');
        return true;
    }
    getSnapshotBeforeUpdate(){
        console.log('getSnapshotBeforeUpdate() is called');
        return null;
    }
    componentDidMount(){
        console.log('componentDidMount() is called');
    }
    componentDidUpdate(){
        console.log('componentDidUpdate() is called');
    }
    componentWillUnmount(){
        console.log('componentWillUnmount() is called')
    }
}

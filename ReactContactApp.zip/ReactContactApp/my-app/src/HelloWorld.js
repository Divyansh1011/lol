import React,{Component} from "react";


// export class HelloWorld extends Component{
// 	render(){
//         //console.log(this);
            
// 		return <div>
// 			        <h1>Hello, World!</h1>
// 			        <hr/>
// 			        <p>{this.props.msg}</p>
//                     <p>X={this.props.x}</p>
// 		     </div>;
// 	}
// }


export const HelloWorld =(props)=>{    
    props.x=props.x+1;
    
    return <div>
                <h1>Hello, World!</h1>
                <hr/>
                <p>{props.msg}</p>
                <p>X={props.x}</p>
            </div>;
}
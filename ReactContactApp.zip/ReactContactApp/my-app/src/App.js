import logo from './logo.svg';
import './App.css';
import {Component} from 'react';

// function App() {
 
//   return (
//     <div className="App">
//      <h1>This is my first ReactJS Application</h1>
//     </div>
//   );
// }

class App extends Component{

    state={num:0};

    increment=()=>{
          this.setState({num:this.state.num});
          console.log(this.state);
    }

    decrement=()=>{
      this.setState({num:this.state.num-1});
      console.log(this.state);
    }
    render(){       
        return (<div style={{margin:10+'px'}}>
            <h1>ReactJS Counter Application</h1>

            <h3>Value of num is {this.state.num}</h3>

            <button onClick={this.increment} >
              Increment
            </button>
            <button onClick={this.decrement} >
              Decrement
            </button>
        </div>);
    }

}

export default App;

import React, { Component } from "react";
import './AppContent.css';
//import ContactCard from "./ContactCard";
import { ContactList } from "./ContactList";
import ContactForm from "./ContactForm";
import ContactDetails from "./ContactDetails";

import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import ContactDetailsHooks from "./ContactDetailsHooks";
import AxiosApiCalls from "./AxiosApiCalls";

const contact = {
    name: 'Alexa',
    email: 'alexa@amazon.com',
    phone: '987363533',
    picture: 'images/alexa.jpg'
};

// const contacts = [
//     {
//         id: 1,
//         name: 'Alexa',
//         email: 'alexa@amazon.com',
//         phone: '987363533',
//         picture: 'images/1.jpg'
//     },
//     {
//         id: 2,
//         name: 'Siri',
//         email: 'siri@flipkart.com',
//         phone: '643444533',
//         picture: 'images/siri.jpg'
//     },
//     {
//         id: 3,
//         name: 'David',
//         email: 'david@amazon.com',
//         phone: '987363533',
//         picture: 'images/david.jpg'
//     },
//     {
//         id: 4,
//         name: 'John Doe',
//         email: 'john@amazon.com',
//         phone: '987361234',
//         picture: 'images/john.jpg'
//     }

// ];

// const contactCards = contacts
// .map(c => <ContactCard key={c.id} contact={c} />);






const Home = (props) => {

    return (
        <div>
            <h3>Welcome to Addressbook Application</h3>
            <hr />
            <p>Powered by React</p>
        </div>
    )
}


export class AppContent extends Component {
    // state = {
    //     contacts: []
    // }
    // constructor() {
    //     super();
    //     fetch("http://localhost:4300/contacts")
    //     .then(response => response.json())
    //     .then(data => this.setState({ contacts: data }));  
    // }  

    render() {        

        return (
            <Router>
                <div className="container">
                    <div className="row">
                        <div className="col-md-4">
                            <ul className="list-group">
                                <li className="list-group-item">
                                    <Link to="/">
                                        Home
                                    </Link>
                                </li>
                                <li className="list-group-item">
                                    <Link to="/add-new-contact">
                                        Add a new contact
                                    </Link>
                                </li>
                                <li className="list-group-item">
                                    <Link to="/view-all-contacts">
                                        View all contacts
                                    </Link>
                                </li>
                            </ul>
                        </div>
                        <div className="col-md-8">
                            <Routes>
                                <Route path="/" exact element={<AxiosApiCalls />} />
                                <Route path="/add-new-contact" exact element={<ContactForm />} />
                                <Route path="/view-all-contacts" exact element={<ContactList />} />
                                <Route path="/contact-details/:id" exact element={<ContactDetails />} />
                            </Routes>
                        </div>
                    </div>
                </div>
            </Router>
        )
    }
}
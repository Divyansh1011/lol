import { useState } from 'react';
import AppCounter from './AppCounter';

 const CounterHomeHooks = () => {

    const [showHide, updateShowHide] = useState(true);

    const [name,setName]=useState("");

    const [emp,setEmp]=useState({ecode:101,ename:'Ravi',salary:5000});

    let output = null;
    if (showHide) {
        output = <AppCounter title="Counter Lifecycle methods" />
    }
    return (
        <div>
            <button className='btn btn-danger'
                onClick={() => {
                    //showHide=!showHide;
                    updateShowHide(showHide);
                    setName("Ramnath");
                    if(emp.salary>=5000){
                        setEmp({...emp,salary:emp.salary+1000})
                    }
                }}>
                Show/Hide
            </button>
            <div>
                {output}
            </div>
            Name :{name}
            <p>Ecode:{emp.ecode}</p>
            <p>Ename:{emp.ename}</p>
            <p>Salary:{emp.salary}</p>
            
        </div>
    )
}

export default CounterHomeHooks;
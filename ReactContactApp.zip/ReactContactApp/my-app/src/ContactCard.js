import React from "react";
import { Link } from "react-router-dom";

const ContactCard =({contact,deleteByContactId})=>{ 
      
    return(
    <div className="card" style={{width:'400px',padding:'10px',margin:'10px'}}>
        <div className="row">
            <div className="col-md-4">
                <img src={contact.picture} 
                    alt={contact.picture}
                    width='100px' 
                    height='100px' 
                    className="card-img"/>
            </div>
            <div className="col-md-8">
                <div className="card-body">
                    <h5 className="card-title">
                        <Link to={"/contact-details/"+contact.id}>
                            {contact.name}
                        </Link>
                        <button className="btn float-right" 
                                onClick={()=>{
                                    deleteByContactId(contact.id)
                                }} 
                                style={{color:'red'}}>&times;</button>
                    </h5>
                    <div className="card-text">{contact.email}</div>
                    <div className="card-text">{contact.phone}</div>
                </div>
            </div>
        </div>
    </div>
    )
}

export default ContactCard;
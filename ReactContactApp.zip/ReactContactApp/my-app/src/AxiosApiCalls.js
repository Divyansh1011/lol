import {useState,useEffect} from "react";
import axios from "axios";
import ContactCard from "./ContactCard";

const baseUrl = "http://localhost:4300/contacts";
const AxiosApiCalls = () => {

    const [contacts, setContacts] = useState(null);


    useEffect(()=>{
        axios.post(baseUrl,{
            name:'Ravi',
            email:'ravi@gmail.com',
            phone:'1234567890',
            picture:'1.jpg'
        }).then(response=>{
            setContacts(response.data);
        });
    },[]);



    useEffect(()=>{
        axios.get(baseUrl).then(response => { 
            setContacts(response.data);
            console.log('useEffect'); 
        }); 
    },[]);


       


    if (contacts) {
        const deleteByContactId = (id) => {
            fetch("http://localhost:4300/contacts/" + id,
                {
                    method: 'DELETE'
                })
                .then(response => response.json())
                .then((data) => {
                    alert('Record deleted for id:' + data.id);                
                });
        } 

        return (            
            <div>
                <h1 className="alert alert-info">List of contacts</h1>
                {contacts.map(c => <ContactCard key={c.id} contact={c} deleteByContactId={deleteByContactId}/>)}
            </div>
        )
    }
}
export default AxiosApiCalls;
import React,{Component, Fragment} from "react";


export default class AppHeader extends Component{
    render(){
        return (
            <Fragment>
                <h1 className="alert alert-danger">{this.props.title}</h1>
                <p>{this.props.subheading}</p>
                <hr/>
            </Fragment>
        );
    }
}

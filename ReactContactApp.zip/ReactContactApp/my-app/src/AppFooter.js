import { Component } from "react";
import './AppFooter.css';

export default function AppFooter ({year,website,company}){
    return (
            <div>
                <p className="app-footer">&copy; {year} - All rights reserved by Ramnath Inc.</p>
                <a href={website}>{company}</a>
            </div>
    );
}

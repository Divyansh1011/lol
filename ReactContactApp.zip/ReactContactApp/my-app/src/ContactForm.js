import React, { Component } from "react";
import { Navigate } from "react-router-dom";


export default class ContactForm extends Component {   

    state = {
        name: "",
        email: "",
        phone: "",
        picture: "",
        formErrors: {
            name: 'Name is required',
            email: 'Email is required',
            phone: 'Phone is required'
        },
        errorMessages: "",
        navFlag:false
    }

    addNewContact = (event) => {
        event.preventDefault();

        const name = this.state.name; //or this.refs['name].value
        const email = this.state.email;
        const phone = this.state.phone;
        const picture = "images/"+this.state.picture;

        const contact = { name, email, phone, picture };
        console.log(contact);


        // this.refs.name.value=""; //to clear the fields
        // this.refs.email.value="";
        // this.refs.phone.value="";
        // this.refs.picture.value="";       

        let { formErrors } = this.state;
        if (this.validateForm(formErrors)) {
 
            //POST request using FETCH API
            fetch("http://localhost:4300/contacts", {
                method: 'POST',
                body: JSON.stringify(contact),
                headers: {
                    'Content-type': 'application/json;charset=UTF-8'
                }
            })
            .then(response=>response.json())
            .then(data=>{
                alert('Record inserted for id:'+data.id);
                this.setState({navFlag:true});
            });
        }

        let errorMessages = Object.values(formErrors)
            .map((err) => err.length === 0 ? null : <li>{err}</li>);


        this.setState({ errorMessages });
    }
    validateForm(formErrors) {
        let valid = true;
        //check the error msgs
        Object.values(formErrors).forEach(err => valid = valid && err.length === 0)
        return valid;
    }

    tfHandler = (event) => {
        //console.log(event.target.value);        
        //let v=event.target.value;
        //this.setState({[event.target.name]:v});

        let { name, value } = event.target;
        let { formErrors } = this.state;

        switch (name) {
            case 'name':
                if (!value || value.length === 0) {
                    formErrors.name = 'Name is required';
                }
                else if (value.length < 3 || value.length > 20) {
                    formErrors.name = 'Name must be between 3 and 20 letters';
                }
                else {
                    formErrors.name = '';
                }
                console.log(formErrors);
                break;
            case 'email':
                if (!value || value.length === 0) {
                    formErrors.email = 'Email is required';
                }
                else if (!value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/i)) {
                    formErrors.email = 'Not a valid email';
                }
                else {
                    formErrors.email = '';
                }
                break;
            case 'phone':
                if (!value || value.length === 0) {
                    formErrors.phone = 'Phone is required';
                }
                else if (!value.match(/^\d{10,12}$/)) {
                    formErrors.phone = 'Not a valid phone';
                }
                else {
                    formErrors.phone = '';
                }
                break;
            default:
                break;
        }

        this.setState({ [name]: value, formErrors });
    }

    

    render() {
        //console.log('render called');
        if(this.state.navFlag)
            return (<Navigate to="/view-all-contacts" />);
        return (
            <div>
                {/* <h3>Current state</h3>
                <pre>{JSON.stringify(this.state,null,3)}</pre> */}

                <h3>Add a new contact form</h3>
                <form className="form" onSubmit={this.addNewContact}>
                    <div className="form-group row">
                        <label className="control-label col-md-4">
                            Name
                        </label>
                        <div className="col-md-8">
                            <input name="name" type="text" value={this.state.name} className="form-control" onChange={this.tfHandler} />
                        </div>
                    </div>
                    <div className="form-group row">
                        <label className="control-label col-md-4">
                            Email address
                        </label>
                        <div className="col-md-8">
                            <input name="email" type="text" value={this.state.email} className="form-control" onChange={this.tfHandler} />
                        </div>
                    </div>
                    <div className="form-group row">
                        <label className="control-label col-md-4">
                            Phone number
                        </label>
                        <div className="col-md-8">
                            <input name="phone" type="text" value={this.state.phone} className="form-control" onChange={this.tfHandler} />
                        </div>
                    </div>
                    <div className="form-group row">
                        <label className="control-label col-md-4">
                            Picture
                        </label>
                        <div className="col-md-8">
                            <input name="picture" type="text" value={this.state.picture} className="form-control" onChange={this.tfHandler} />
                        </div>
                    </div>
                    <button className="btn btn-primary">Save data</button>
                </form>
                <ul>
                    {this.state.errorMessages}
                </ul>
            </div>
        )
    }
}
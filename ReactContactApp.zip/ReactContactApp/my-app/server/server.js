const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

//connect to MongoDB database using mongoose
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/phonebookDB').then(res => {
    console.log("mongodb connection established");
});

//create the database model for db operations and queries
let Contact = mongoose.model("address",
    new mongoose.Schema({
        id: { type: Number },
        name: { type: String },
        phone: { type: String },
        email: { type: String },
        picture: { type: String }
    }, {
        collection: 'address'
    }));





const app = express(); //create the express web app object
app.use(cors({
    origin: "*",
    methods: "*"
}))
app.use(bodyParser.json())    //------application/json



//configure for requests and response for different api methods:GET,POST,PU and DELETE

//default request
app.get("/", function (req, res) {
    res.send("<h2>Welcome to AddressBook API Server </h2>");
});

//get all request
app.get("/api/contacts", function (req, res) {
    //get all the contacts record from database using Model
    Contact.find((err, contacts) => {
        if (err) {
            res.send(err);
        }
        res.json(contacts);
    });

    //res.send("<h1>You have sent Get All Request</h1>");
});

//get by id request
app.get("/api/contacts/:id", function (req, res) {
    let id = Number(req.params.id);

    Contact.findOne({ "id": id }, function (err, data) {
        if (err) {
            res.send(err);
        }
        res.json(data);
    });
});


//delete by id request
app.delete("/api/contacts/:id", function (req, res) {
    let id = req.params.id;
   // console.log(id);

    Contact.deleteOne({ "id": id }, function (err, data) {
        if (err) {
            res.send(err);
        }
        else {
            Contact.find(function (err, data) {
                if (err) {
                    res.send(err);
                }
                res.json(data);
            })
        };
    })
})

//insert by id
app.post("/api/contacts", function (req, res) {
    //create a new model instance
    let contact = new Contact();

    //get the next new id
    Contact.findOne().sort({ id: -1 })
        .then((data) => {
            contact.id = data.id + 1;
            //specify the values to the fields of the model from request body
            //contact.id = req.body.id;
            contact.name = req.body.name;
            contact.email = req.body.email;
            contact.phone = req.body.phone;
            contact.picture = req.body.picture;

            //save the model to DB
            contact.save(function (err) {
                if (err) {
                    res.send(err);
                }
                Contact.find(function (err, data) {
                    if (err) {
                        res.send(err);
                    }
                    res.json(data);
                });
            });
        });
});


//update by id
app.put("/api/contacts/:id", function (req, res) {

    //get the value of id from request route params
    let id = Number(req.params.id);

    //find the document by id in DB
    Contact.findOne({ "id": id }).then(contact => {
        if (contact) {
            //if document is found, 
            //specify the values to the fields of the model from request body            
            contact.name = req.body.name;
            contact.email = req.body.email;
            contact.phone = req.body.phone;
            contact.picture = req.body.picture;

            //save the modified document in DB
            contact.save().then(c => {
                res.status(200).json(c);
            });
        }
    });
});


//start the app at http://localhost:4300
const port = 4300;
app.listen(port, () => console.log(`Addressbook server app started on port ${port} `));

